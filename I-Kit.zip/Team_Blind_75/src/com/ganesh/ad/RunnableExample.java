package com.ganesh.ad;

//Java Program to implement Runnable interface

//Importing FileNotFound class from
//input output classes bundle
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.concurrent.*;


class Player {
    private int ranking;
    private String name;
    private int age;
	public int getRanking() {
		// TODO Auto-generated method stub
		return ranking;
	}
    
    // constructor, getters, setters  
}
//Class
//Implementing the Runnable interface 
class RunnableImpl implements Runnable {

public void run()
{
	System.out.println("Hello World from a different thread than Main");
}
}
public class RunnableExample{
	static ExecutorService executor = Executors.newFixedThreadPool(2);
public static void main(String[] args){
	
	Comparator<Player> comparator = (p1, p2) -> p1.getRanking() - p2.getRanking();
	
	Comparator.comparing(Player::getRanking);
		// Creating and running runnable task using Thread class
		RunnableImpl task = new RunnableImpl();
		Thread thread = new Thread(()->{
			System.out.println("Hello World from a different thread than Main");
		});
		System.out.println(thread.isAlive());
		thread.start();
		System.out.println(thread.isAlive());
		
		Runnable r = ()->{
			System.out.println("Hello World from a different thread than Main");
		};
		
		Thread threadw = new Thread(r);
		// Creating and running runnable task using Executor Service.
		executor.submit(()->{
			System.out.println("Hello World from a different thread than Main");
		});
	}
}
