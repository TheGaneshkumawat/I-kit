package com.ganesh.ad.single;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;

public class Singleton2 implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Singleton2 ONLY_INSTANCE = null;
	
	private Singleton2() {
		
	}
	
	public static Singleton2 getInstance() {		
		if(null == ONLY_INSTANCE) {
			ONLY_INSTANCE = new Singleton2();	
		}				
		return ONLY_INSTANCE;
	}
	
	private Object readResolve() throws ObjectStreamException {
		System.out.println("Inside read resolve");
		return ONLY_INSTANCE;		
	}
	
	private void writeObject(ObjectOutputStream oos) 
      throws IOException {
        //oos.defaultWriteObject();
        System.out.println("Inside write object");        
    }

    
	public static void main(String[] args) throws Exception {
		Singleton2 s1 = Singleton2.getInstance();
		Singleton2 s2 = Singleton2.getInstance();
		
		System.out.println("s1: "+s1.hashCode());
		System.out.println("s2: "+s2.hashCode());
			
		ObjectOutputStream oo = new ObjectOutputStream(new FileOutputStream("a.txt"));
		oo.writeObject(s1);
		oo.flush();
		oo.close();
		
		ObjectInputStream oi = new ObjectInputStream(new FileInputStream("a.txt"));
		Object newInstance = (Singleton2) oi.readObject();
		oi.close();
		
		System.out.println("new: "+newInstance.hashCode());

	}

}
