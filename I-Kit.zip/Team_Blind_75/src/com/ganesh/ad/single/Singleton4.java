package com.ganesh.ad.single;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Singleton4 implements Cloneable {

	private static Singleton4 ONLY_INSTANCE = null;
	
	private Singleton4() {
		
	}
	
	public static  Singleton4 getInstance() {		
		
		synchronized(Singleton4.class) {
			if(null == ONLY_INSTANCE) {				
				ONLY_INSTANCE = new Singleton4();	
			}	
		}
						
		return ONLY_INSTANCE;
	}
	
	public static void useSingleton() {
		Singleton4 s1 = Singleton4.getInstance();
		System.out.println("New Object: "+s1.hashCode());
	}
	
	public static void main(String[] args) throws Exception {
		Singleton4 s1 = Singleton4.getInstance();
		Singleton4 s2 = Singleton4.getInstance();
		
		System.out.println("s1: "+s1.hashCode());
		System.out.println("s2: "+s2.hashCode());
			
		ExecutorService service = Executors.newFixedThreadPool(2);
		
		service.submit(Singleton4::useSingleton);
		service.submit(Singleton4::useSingleton);
		service.submit(Singleton4::useSingleton);
		service.submit(Singleton4::useSingleton);
		service.submit(Singleton4::useSingleton);
		service.submit(Singleton4::useSingleton);
		
		service.shutdown();
		
	}

}
