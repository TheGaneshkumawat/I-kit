package com.ganesh.ad.single;

import java.lang.reflect.Constructor;

public class Singleton {

	public static Singleton ONLY_INSTANCE = null;
	
	private Singleton() {
		if(null != ONLY_INSTANCE) {
			throw new RuntimeException("Cannot create");
		}
	}
	
	public static Singleton getInstance() {		
		if(null == ONLY_INSTANCE) {
			ONLY_INSTANCE = new Singleton();	
		}				
		return ONLY_INSTANCE;
	}
	
	public static void main(String[] args) throws Exception {
		Singleton s1 = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
			
		
		@SuppressWarnings("unchecked")
		Class<Singleton> clas = (Class<Singleton>) Class.forName("com.ganesh.ad.single.Singleton");
		Constructor<Singleton> declaredConstructor = clas.getDeclaredConstructor();
		declaredConstructor.setAccessible(true);
		Singleton newInstance = declaredConstructor.newInstance();
		
		System.out.println(newInstance.hashCode());

	}

}
