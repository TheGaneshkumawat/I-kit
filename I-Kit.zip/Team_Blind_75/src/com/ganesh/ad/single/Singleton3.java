package com.ganesh.ad.single;

public class Singleton3 implements Cloneable {

	public static Singleton3 ONLY_INSTANCE = null;
	
	private Singleton3() {
		
	}
	
	public static Singleton3 getInstance() {		
		if(null == ONLY_INSTANCE) {
			ONLY_INSTANCE = new Singleton3();	
		}				
		return ONLY_INSTANCE;
	}
	
	protected Object clone() throws CloneNotSupportedException{
		System.out.println("Inside clone...");
		return ONLY_INSTANCE;		
	}
	
	public static void main(String[] args) throws Exception {
		Singleton3 s1 = Singleton3.getInstance();
		Singleton3 s2 = Singleton3.getInstance();
		
		System.out.println("s1: "+s1.hashCode());
		System.out.println("s2: "+s2.hashCode());
			
		
		
		Object newInstance = s1.clone();
		
		
		System.out.println("new: "+newInstance.hashCode());

	}

}
