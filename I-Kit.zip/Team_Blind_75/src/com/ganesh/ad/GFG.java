package com.ganesh.ad;

import java.util.Arrays;

//Java Program to Create An Immutable Class

//Importing required classes
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//Class 1
//An immutable class
final class Student {

	// Member attributes of final class
	private final String name;
	private final int regNo;
	private final Map<String, String> metadata;

	// Constructor of immutable class
	// Parameterized constructor
	public Student(String name, int regNo,
				Map<String, String> metadata)
	{

		// This keyword refers to current instance itself
		this.name = name;
		this.regNo = regNo;

		// Creating Map object with reference to HashMap
		// Declaring object of string type
		Map<String, String> tempMap = new HashMap<>();

		// Iterating using for-each loop
		for (Map.Entry<String, String> entry :
			metadata.entrySet()) {
			tempMap.put(entry.getKey(), entry.getValue());
		}

		this.metadata = tempMap;
	}

	// Method 1 
	public String getName() { return name; }

	// Method 2 
	public int getRegNo() { return regNo; }

	// Note that there should not be any setters 

	// Method 3
	// User -defined type
	// To get meta data
	public Map<String, String> getMetadata()
	{

		// Creating Map with HashMap reference
		Map<String, String> tempMap = new HashMap<>();

		for (Map.Entry<String, String> entry :
			this.metadata.entrySet()) {
			tempMap.put(entry.getKey(), entry.getValue());
		}
		return tempMap;
	}
}

//Class 2
//Main class
public class GFG {

	// Main driver method
	public static void mains(String[] args) throws InterruptedException
	{
		
	

		//
		
		
		// Creating Map object with reference to HashMap
		Map<String, String> map = new HashMap<>();

		// Adding elements to Map object
		// using put() method
		map.put("1", "first");
		map.put("2", "second");
		String ss = "ABC";
		ss = "aaa";		
				
		Student s = new Student(ss, 101, map);
		
		// Calling the above methods 1,2,3 of class1
		// inside main() method in class2 and
		// executing the print statement over them
		System.out.println(s.getName());
		System.out.println(s.getRegNo());
		System.out.println(s.getMetadata());

		// Uncommenting below line causes error
		// s.regNo = 102;

		map.put("3", "third");
		// Remains unchanged due to deep copy in constructor
		System.out.println(s.getMetadata());
		s.getMetadata().put("4", "fourth");
		// Remains unchanged due to deep copy in getter
		System.out.println(s.getMetadata());
		
		
		Thread t = new Thread(() -> System.out.println("hello world"));
		t.run();
		Thread.sleep(1000);
		t.start();
	}
	
	public static void main (String[] args) 
    { 
		sortString("geeksforgeeks");
    }
	
	 static void sortString(String str) {
		 int MAX_CHAR = 26;
		 
	        // Hash array to keep count of characters.
	        int letters[] = new int[MAX_CHAR];
	 
	        // Traverse string and increment
	        // count of characters
	        for (char x : str.toCharArray()) {
	 
	            // 'a'-'a' will be 0, 'b'-'a' will be 1,
	            // so for location of character in count
	            // array we will do str[i]-'a'.
	            letters[x - 'a']++;
	        }
	 
	        System.out.println(Arrays.toString(letters));	        
	        
	        
	        // Traverse the hash array and print
	        // characters
	        for (int i = 0; i < MAX_CHAR; i++) {
	            for (int j = 0; j < letters[i]; j++) {
	                System.out.print((char) (i + 'a'));
	            }
	        }
	    }
		
	
	 public static void mainss (String[] args) 
	    { 
			char ch1 = 'z';  
			char ch2 = ' ';  
			// variable that stores the integer value of the character  
			int asciivalue1 = ch1;  
			int asciivalue2 = ch2;  
			System.out.println("The ASCII value of " + ch1 + " is: " + (char)121);  
			System.out.println("The ASCII value of " + ch2 + " is: " + asciivalue2);  
			
			
				
			char[] ch = {'1','3','5','2','4'};
			 
			
			
			String my = new String(ch);
			
			List<Character> collect = my.chars().mapToObj(c -> (char) c).collect(Collectors.toList());
			List<Integer> collect2 = collect.stream().map(x->Integer.parseInt(x+"")).collect(Collectors.toList());
			
			//System.out.println(collect.size());
			collect.stream().forEach(System.out::println);
			collect2.stream().forEach(System.out::println);
			
			//List<Integer> collect = list.stream().map(x->Integer.parseInt(new String(x))).collect(Collectors.toList());
			
			//System.out.println(collect);
			
			
	        // creating two threads 
	        ThreadJoining t1 = new ThreadJoining(); 
	        ThreadJoining t2 = new ThreadJoining(); 
	        ThreadJoining t3 = new ThreadJoining(); 
	  
	        // thread t1 starts 
	       // t1.start(); 
	  
	        // starts second thread after when 
	        // first thread t1 has died. 
	        try
	        { 
	            System.out.println("Current Thread: "
	                  + Thread.currentThread().getName()); 
	          //  t1.join(); 
	        } 
	  
	        catch(Exception ex) 
	        { 
	            System.out.println("Exception has " + 
	                                "been caught" + ex); 
	        } 
	  
	        // t2 starts 
	        //t2.start(); 
	  
	        // starts t3 after when thread t2 has died. 
	        try
	        { 
	            System.out.println("Current Thread: "
	                 + Thread.currentThread().getName()); 
	            //t2.join(); 
	        } 
	  
	        catch(Exception ex) 
	        { 
	            System.out.println("Exception has been" + 
	                                    " caught" + ex); 
	        } 
	  
	        //t3.start(); 
	    } 

	 

}

class ThreadJoining extends Thread 
{ 
    @Override
    public void run() 
    { 
        for (int i = 0; i < 2; i++) 
        { 
            try
            { 
                Thread.sleep(5000); 
                System.out.println("Current Thread: "
                        + Thread.currentThread().getName()); 
            } 
  
            catch(Exception ex) 
            { 
                System.out.println("Exception has" + 
                                " been caught" + ex); 
            } 
            System.out.println(i); 
        } 
    } 
} 
