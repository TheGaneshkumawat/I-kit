package com.ganesh.ad;

interface MyInterface{
	   public static void display() {
	      System.out.println("Static method of the interface");
	   }
	}

	class Test {
		 public void display() {
			 throw new NullPointerException();
		   }
	}
	public class InterfaceExample extends Test{
		
		 public void display(String a) {
		      throw new RuntimeException();
		   }
		 
		 public void display(Test t) {
		      throw new RuntimeException();
		   }
		
		 public void display() {
		      throw new RuntimeException();
		   }
	   public static void main(String args[]) {
		   Test obj = new InterfaceExample();
		   
		   
		   
		   obj.display();
	   }
	}
	
	