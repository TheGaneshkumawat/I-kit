package com.ganesh.ad;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class Blind_75 {

	public static void main(String[] args) {
		int[] nums = { 1, 2, 3, 1 };

		String s = "A man, a plan, a canal: Panama";

		int[] prices = { 1, 3 };
		// System.out.println(isValid("()"));
		// System.out.println(binarySearch(prices,91));
		// System.out.println(findMin(prices));

		ListNode l1 = new ListNode(1, new ListNode(2, new ListNode(4)));
		ListNode l2 = new ListNode(1, new ListNode(3, new ListNode(4)));

		// System.out.println(mergeTwoLists(l1,l2));
		// System.out.println(Arrays.toString(countBits(11)));
		// System.out.println(hammingWeight(5));

		Object obj = new Blind_75();
		System.out.println(obj.toString());

		int a[] = { 0, 1, 2, 4 };
		System.out.println(missingNumber(a));

	}

	 

	public static int missingNumber(int[] nums) {

		int sum = 0;
		int total = nums.length * (nums.length + 1) / 2;

		System.out.println("total: " + total);
		for (int j = 0; j < nums.length; j++) {

			sum += nums[j];
		}

		return total - sum;
	}

	public int[] countBits1(int n) {

		int[] res = new int[n + 1];
		res[0] = 0;
		int off = 1;
		for (int j = 1; j <= n; j++) {

			if (off * 2 == j) {
				off = j;
			}

			res[j] = 1 + res[j - off];
		}

		return res;

	}

	public static int[] countBits(int n) {

		int[] res = new int[n + 1];

		for (int j = 0; j <= n; j++) {
			res[j] = hammingWeight(j);
		}

		return res;

	}

	public static int hammingWeight(int n) {
		int res = 0;

		while (n > 0) {
			res += n % 2;
			n = n >> 1;
		}

		return res;
	}

	// 0-30 8-5
	public boolean canAttendMeetings(List<Interval> intervals) {

		for (int i = 0; i < intervals.size(); i++) {
			Interval e = intervals.get(i);

			for (int j = i + 1; j < intervals.size(); j++) {
				Interval e2 = intervals.get(j);

				if (e2.start < e.end && e2.start > e.start) {
					return false;
				}
			}

		}

		return true;
	}

	public boolean canAttendMeetings1(List<Interval> intervals) {
		Collections.sort(intervals, (a, b) -> a.start - b.start);

		for (int i = 0; i + 1 < intervals.size(); i++) {
			if (intervals.get(i).end > intervals.get(i + 1).start) {
				return false;
			}
		}
		return true;
	}

	public static int climbStairs(int n) {

		int one = 1;
		int two = 1;

		for (int i = 0; i < n - 1; i++) {

			int tmp = one;
			one = one + two;
			two = tmp;

		}

		return one;

	}

	public boolean isSubtree(TreeNode root, TreeNode subRoot) {

		if (subRoot == null || isSameTree(root, subRoot))
			return true;
		if (root == null)
			return false;

		return isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot);
	}

	public static boolean isSameTree(TreeNode p, TreeNode q) {

		if (null == p && null != q) {
			return false;
		}

		if (null == q && null != p) {
			return false;
		}

		if (null == p && null == q) {
			return true;
		}

		return (p.val == q.val) && isSameTree(p.left, q.left) && isSameTree(p.right, q.right);
	}

	public static int maxDepth(TreeNode root) {

		int i = 0;

		if (root == null) {
			return i;
		}

		return depth(root, i);

	}

	public static int depth(TreeNode root, int i) {
		if (null == root) {
			return i;
		}

		i++;
		i = Math.max(depth(root.left, i), depth(root.right, i));

		return i;
	}

	public static TreeNode invertTree(TreeNode root) {
		if (null == root) {
			return null;
		}

		TreeNode left = root.left;
		root.left = root.right;
		root.right = left;

		invertTree(root.left);
		invertTree(root.right);

		return root;
	}

	public static boolean hasCycle(ListNode head) {

		ListNode slow = head;
		ListNode fast = head;

		while (fast != null && fast.next != null) {

			slow = slow.next;
			fast = fast.next.next;

			if (fast == slow) {
				return true;
			}
		}

		return false;
	}

	public static ListNode mergeTwoLists(ListNode list1, ListNode list2) {
		ListNode fin = new ListNode();
		ListNode res = fin;

		while (list1 != null && list2 != null) {

			System.out.println("result: " + res);
			System.out.println("final: " + fin);

			if (list1.val <= list2.val) {
				res.next = list1;
				list1 = list1.next;
			} else {
				res.next = list2;
				list2 = list2.next;
			}

			res = res.next;

		}

		if (list1 == null) {
			res.next = list2;
		}

		if (list2 == null) {
			res.next = list1;
		}

		return fin.next;
	}

	public static ListNode reverseList2(ListNode head) {

		return reverse(head, null);
	}

	public static ListNode reverse(ListNode head, ListNode pre) {
		if (null == head) {
			return pre;
		}

		ListNode tmp = head.next;
		head.next = pre;

		return reverse(tmp, head);

	}

	public static ListNode reverseList(ListNode head) {

		ListNode next = new ListNode();
		ListNode current = head;
		ListNode prev = null;

		while (head != null) {

			current = head;
			next = head.next;
			current.next = prev;

			prev = current;
			head = next;

		}

		return current;
	}

	public static int search(int[] nums, int target) {
		int res = -1;

		int i = 0;
		int j = nums.length - 1;

		while (i <= j) {
			int mid = (i + j) / 2;

			if (target == nums[mid]) {
				return mid;
			}

			if (nums[i] <= nums[mid]) {
				if (target > nums[mid] || target < nums[i]) {
					i = mid + 1;
				} else {
					j = mid - 1;
				}
			} else {
				if (target < nums[mid] || target > nums[j]) {
					j = mid - 1;
				} else {
					i = mid + 1;
				}
			}

		}

		return res;
	}

	public static int findMin(int[] nums) {
		int min = nums[0];

		int i = 0;
		int j = nums.length - 1;

		while (i <= j) {
			int mid = (i + j) / 2;

			if (min <= nums[mid]) {
				i = mid + 1;
			} else {
				min = nums[mid];
				j = mid - 1;
			}

		}

		return min;
	}

	public static int binarySearch(int[] a, int s) {

		int index = -1;

		int i = 0;
		int j = a.length - 1;

		while (i <= j) {
			int mid = (i + j) / 2;

			if (a[mid] == s) {
				return mid;
			}

			if (a[mid] < s) {
				i = mid + 1;
			}

			if (a[mid] > s) {
				j = mid - 1;
			}

		}

		return index;
	}

	public static boolean isValid(String s) {
		Stack<Character> stack = new Stack<Character>();

		Map<Character, Character> m = new HashMap<>();
		m.put(')', '(');
		m.put(']', '[');
		m.put('}', '{');

		for (int i = 0; i < s.length(); i++) {

			char c = s.charAt(i);

			if (m.containsKey(c)) {
				if (!stack.empty() && !stack.peek().equals(m.get(c))) {
					stack.pop();
				} else {
					return false;
				}

			} else {
				stack.add(c);
			}

		}

		return stack.empty();
	}

	public static int maxProfit(int[] prices) {
		int profit = 0;
		int start = 0;
		int end = 1;

		while (end < prices.length) {

			int diff = prices[end] - prices[start];
			System.out.println("start: " + start);
			System.out.println("end: " + end);

			if (prices[start] < prices[end]) {
				profit = Math.max(profit, diff);
			} else {
				start = end;
			}

			end++;

		}

		return profit;
	}

	public static boolean isPalindrome(String s) {
		// caac cac
		s = s.toLowerCase();

		
		int i = 0;
		int j = s.length() - 1;

		while (i < j) {

			char start = s.charAt(i);
			char end = s.charAt(j);

			if (!Character.isLetterOrDigit(start)) {
				i++;
				continue;
			}

			if (!Character.isLetterOrDigit(end)) {
				j--;
				continue;
			}
			if (start != end) {

				return false;
			}

			i++;
			j--;
		}

		return true;
	}

	public static boolean containsDuplicate(int[] nums) {
		Arrays.sort(nums);
		for (int i = 1; i < nums.length; i++) {

			if (nums[i] == nums[i - 1]) {
				return true;
			}

		}
		return false;

	}

	public static boolean isAnagram(String s, String t) {

		boolean res = false;

		if (s.length() != t.length()) {
			return res;
		}
		for (int i = 0; i < s.length(); i++) {

			if (t.indexOf(s.charAt(i)) < 0) {
				return res;
			}
		}

		return true;
	}

//[2,7,11,15]
	public static int[] twoSum(int[] nums, int target) {

		int[] res = new int[2];

		Map<Integer, Integer> map = new HashMap<Integer, Integer>();

		for (int i = 0; i < nums.length; i++) {

			int num = nums[i];
			int diff = target - nums[i];

			if (map.containsKey(diff)) {
				res = new int[] { map.get(diff), i };
			}

			map.put(num, i);
		}

		return res;

	}

}
