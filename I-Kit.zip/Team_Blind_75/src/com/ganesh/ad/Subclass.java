package com.ganesh.ad;

import java.io.FileNotFoundException;
import java.util.List;


abstract class NestedStaticClass {
	 
	
	NestedStaticClass(){
		
	}
	
	public abstract void helo();
    // Only static members of Outer class
    // is directly accessible in nested
    // static class
    public void printMessage()
    {

        // Try making 'message' a non-static
        // variable, there will be compiler error
        System.out.println(
            "Message from nested static class: " );
    }
}




class Superclass{
	
	

	 static void m1()
	    {
	        System.out.println("From parent "
	                           + "static m1()");
	    }
	public Object display(Object o) throws Exception {
		System.out.println("Inside superclass");
		return null;
	}
}

public class Subclass extends Superclass{
	
	 static void m1()
    {
        System.out.println("From child  "
                           + "static m1()");
    }
	public String display(Object o) throws FileNotFoundException{
		
		System.out.println("Inside subclass");
		o.toString();
		
		return null;
	}

	public static void main(String[] args) throws Exception {
		Superclass s = new Subclass();
		
		s.m1();
		
		s.display(new String());

	}
	

}
