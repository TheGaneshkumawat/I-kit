package com.ganesh.ad;

public// Java program Find Out the Number of Objects Created
//of a Class 
class Test1 {

	static int noOfObjects = 0;

	// Instead of performing increment in the constructor
	// instance block is preferred to make this program generic.
	{
		noOfObjects++;
		System.out.println("default");
	}
	static {

		System.out.println("Static");
	}

	// various types of constructors
	// that can create objects
	public Test1() {
		System.out.println("core const");
	}

	public static void main(String args[]) {
		Test1 t1 = new Test1();

		Test1 at1 = new Test1();

		// We can also write t1.noOfObjects or
		// t2.noOfObjects or t3.noOfObjects
		System.out.println(Test1.noOfObjects);
	}
}
