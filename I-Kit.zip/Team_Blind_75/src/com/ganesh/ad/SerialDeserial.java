package com.ganesh.ad;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

class Person implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	static String country = "ITALY";
    transient String job;    
    private int age;
    //private int salary;
    private String name;
    transient int height;
    
    
	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", height=" + height + ", job=" + job + "]";
	}
	
	private void writeObject(ObjectOutputStream oo) throws IOException {
		oo.defaultWriteObject();
		oo.writeObject(this.job);
	}
	
	
	private void readObject(ObjectInputStream oi) throws IOException, ClassNotFoundException {
		oi.defaultReadObject();
		this.setJob((String) oi.readObject());
	}
	
	public void setAge(int i) {
		this.age=i;
	}
	public void setName(String string) {
		this.name=string;
		
	}
	public void setJob(String string) {
		this.job = string;	
	}
	
	public String getJob() {
		return this.job;	
	}
	
}
public class SerialDeserial {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		
		whenSerializingAndDeserializing_ThenObjectIsTheSame();
	}
	
	 
	public static void whenSerializingAndDeserializing_ThenObjectIsTheSame() 
	  throws IOException, ClassNotFoundException { 
	    Person person = new Person();
	    person.setAge(20);
	    person.setName("Joe");
	    person.setJob("Fire");  
				
	  FileOutputStream fileOutputStream = new FileOutputStream("yourfile.txt");
	  ObjectOutputStream objectOutputStream = new
	  ObjectOutputStream(fileOutputStream); objectOutputStream.writeObject(person);
	  objectOutputStream.flush(); objectOutputStream.close();
		  
		 
	    FileInputStream fileInputStream
	      = new FileInputStream("yourfile.txt");
	    ObjectInputStream objectInputStream
	      = new ObjectInputStream(fileInputStream);
	    Person p2 = (Person) objectInputStream.readObject();
	    
	    System.out.println(p2);
	    
	    objectInputStream.close(); 
	 
	    List<String> list = Arrays.asList("5.6", "7.4", "4", 
                "1", "2.3"); 

		// Using Stream flatMap(Function mapper) 
		list.stream().flatMap(num -> Stream.of(num)).mapToDouble(x->Double.parseDouble(x)). 
		forEach(System.out::println); 
	    
	}

}
