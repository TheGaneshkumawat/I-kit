package com.example.blind;

public class Student{
	
	String name;
	int math;
	int english;
	int hindi;
	
	public Student(String name1,		int math1,
	int english1,
	int hindi1) {
		this.name = name1;
		this.math = math1;
		this.english = english1;
		this.hindi = hindi1;
	}
	
	@Override
	public String toString() {
		
		
		return this.name;
	}
	
} 