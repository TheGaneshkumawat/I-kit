package com.example.blind;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

interface MyInterface{
	   public static int num = 100;
	   public static void display() {
	      System.out.println("display method of MyInterface");
	   }
	}
	public class InterfaceExample implements MyInterface{
	   
		 public static void displaya() {
		      System.out.println("display method of class");
		   }
		 
		public void display() {
	      System.out.println("display method of class");
	   }
	   public static void main(String args[]) {
		   List<String> cities = new ArrayList<>();
		    cities.add("Delhi");
		    cities.add("Mumbai");
		    cities.add("Goa");
		    cities.add("Pune");
		    
		    Consumer<String> printConsumer= city-> System.out.println(city);    
		    cities.forEach(printConsumer);
		    

		    Function<String, Character> getFirstCharFunction = city -> city.charAt(0);
		    cities.stream().map(getFirstCharFunction)
		                   .forEach(System.out::println);
		    
		    
		   MyInterface obj = new InterfaceExample();
		     // obj.displaya(); 
		      
		   InterfaceExample obsj = new InterfaceExample();
	      obsj.displaya();
	   }
	}