package com.example.blind.slidingWindow;

import java.util.HashMap;
import java.util.Map;

public class GKLongestSubstringKDistinct {

	public static void main(String[] args) {
		System.out.println(findLength("cbbebi", 3));
		String s = "Hello i lovr";
		
		System.out.println(s.startsWith("Hello"));
		//System.out.println(distinctItems("araaci"));

	}
	
	public static int findLength(String str, int k) {
		int len = 0;
		
		int ws = 0;
		String s = "";
		
		for(int we = 0 ; we < str.toCharArray().length ; we++) {
			s = s+ str.charAt(we);
			
			int dis = distinctItems(s);
			
			if (dis == k) {
				//System.out.println("dis: "+dis+", length: "+s);
				
				len = Math.max(len, s.length());
			}
			
			if(dis > k) {
				s = s.substring(1);				
			}
			
			
		}
		
		return len;
	}
	
	public static int distinctItems(String str) {
			
		Map<String, String> map = new  HashMap<String, String>();
		for(char a : str.toCharArray()) {
			map.put(a+"", a+"");
		}
		return map.size();
	}

}
