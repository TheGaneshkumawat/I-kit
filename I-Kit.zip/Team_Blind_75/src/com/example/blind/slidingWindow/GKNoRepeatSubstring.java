package com.example.blind.slidingWindow;

import java.util.HashMap;
import java.util.Map;

public class GKNoRepeatSubstring {

	public static void main(String[] args) {
		
	
		System.out.println(findLength("abccde"));

	}

	
	public static int findLength(String str) {
		int len = 0;
				
		String s = "";
		
		for(int we = 0 ; we < str.toCharArray().length ; we++) {
			s = s+ str.charAt(we);
						
			
			if (allDistinct(s)) {
				//System.out.println("dis: "+dis+", length: "+s);
				
				len = Math.max(len, s.length());
			}
			else {
				s = s.substring(1);	
			}
			
							
			
			
			
		}
		
		return len;
	}
	
	public static boolean allDistinct(String str) {
			
		Map<Character, Character> map = new  HashMap<Character, Character>();
		for(Character a : str.toCharArray()) {
			map.put(a, a);
		}
		return str.length() == map.size();
	}
}
