package com.example.blind;

import java.util.Comparator;

public class Producer {
	
	private int counter =0;
	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}


	private int two = 0;
	private int three = 0;
	static int N;
	
	public  synchronized void printEven() throws InterruptedException {
		while(counter<N) {
			
			if(counter %2 == 1) {
				wait();
			}
			
			two = two+2;
			
			System.out.println(two);
			counter++;
			notify();			
			
		}
	}
	
	public  synchronized void printOdd() throws InterruptedException  {
		while(counter<N) {
			
			if(counter %2 == 0) {
				wait();
			}
			
			three = three+3;
			System.out.println(three);
			counter++;
			notify();			
			
		}
	}
	

	public static void main(String[] args) {
		N=19;
		Producer p = new Producer();
		Thread t1 = new Thread(()-> {
			try {
				p.printOdd();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} );
		
		Thread t2 = new Thread(()-> {
			try {
				p.printEven();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} );
		
		t1.start();
		t2.start();
		
		
		Comparator<Producer> cc = (Producer p1, Producer p2)->Integer.compare(p1.counter,p2.counter);
		cc.thenComparing((Producer p1, Producer p2)->Integer.compare(p1.counter,p2.counter)).thenComparing(Comparator.comparing(Producer::getCounter));
		
		Comparator<Producer> cs = Comparator.comparing(Producer::getCounter);
	}

}
