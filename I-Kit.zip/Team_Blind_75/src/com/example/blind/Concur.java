package com.example.blind;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Concur {

	int counter = 1;

	static int N;

	public void printOdd() {

		synchronized (this) {
			while (counter < N) {

				if (counter % 2 == 0) {
					System.out.println("wait odd");
					try {
						wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				System.out.println(counter);

				counter++;
				notify();

			}

		}

	}

	public void printEven() {

		synchronized (this) {
			while (counter < N) {

				if (counter % 2 == 1) {
					System.out.println("wait even");
					try {
						wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

				System.out.println(counter);

				counter++;
				notify();

			}

		}

	}

	public static void main(String[] args) {
		Concur j = new Concur();
		N = 10;

		Thread t1 = new Thread(() -> j.printOdd());
		Thread t2 = new Thread(() -> j.printEven());

		Executor ex = Executors.newFixedThreadPool(2);
		
		ex.execute(() -> j.printOdd());
		ex.execute(() -> j.printEven());
		
		t1.start();
		t2.start();

	}

}

abstract class jack {
	public int value;
 public int hashcode() {
	 
	 List ints = Arrays.asList(1,2,3);
	 List nums = ints;
	 
	 nums.add(3.14);
	 
	 return (int)(value^5);
 }
}
