package com.example.blind;

//Java program to sort hashmap by values
import java.lang.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SortMap {

	// function to sort hashmap by values
	public static HashMap<String, Integer>
	sortByValue(HashMap<String, Integer> hm)
	{
		// Create a list from elements of HashMap
		List<Map.Entry<String, Integer> > list
			= new ArrayList<Map.Entry<String, Integer> >(
				hm.entrySet());

		// Sort the list using lambda expression
		Collections.sort(
			list,
			(i1,
			i2) -> i1.getValue().compareTo(i2.getValue()));

		// put data from sorted list to hashmap
		HashMap<String, Integer> temp
			= new LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> aa : list) {
			temp.put(aa.getKey(), aa.getValue());
		}
		
		
		String s1 = "Baeldung";
		String s2 = new String("Baeldung");
		String s3 = new String("Baeldung").intern();
		String s4 = new String("Baeldung");
		
		System.out.println((s1 == s2));
		System.out.println((s1 == s3));
		System.out.println((s1 == s4));

		
		return temp;
	}
	
	
	public static int factorial(int n) {
		
		if(n == 0) {
			return 1;
		}
		
		
		
		return n * factorial(n-1);
		
	}

	// Driver Code
	public static void main(String[] args)
	{

		HashMap<String, Integer> hm
			= new HashMap<String, Integer>();

		// enter data into hashmap
		hm.put("Math", 98);
		hm.put("Data Structure", 85);
		hm.put("Database", 91);
		hm.put("Java", 95);
		hm.put("Operating System", 79);
		hm.put("Networking", 80);
		Map<String, Integer> hm1 = sortByValue(hm);

		// print the sorted hashmap
		for (Map.Entry<String, Integer> en :
			hm1.entrySet()) {
			System.out.println("Key = " + en.getKey()
							+ ", Value = "
							+ en.getValue());
		}
		
		int res =1;
		for(int i = 5 ; i>0 ; i--) {
			res=res*i;
		}
		
		System.out.println(res);
		System.out.println(factorial(5));
	}
}
