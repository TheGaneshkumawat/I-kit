package com.example.blind;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MainClass implements Serializable{
	
	private void writeObject(ObjectOutputStream oos) 
		      throws IOException {
		        oos.defaultWriteObject();
		        
		    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Optional got = Optional.of("Ganesh"); //will raise Null pointer exception  in case null is passed as argument
		
		String[] aa = new String[10];
		Optional optional = Optional.ofNullable(aa[9]);
		
		//System.out.println(got.isPresent() +"  "+optional.isPresent());
		
		HashMap<Character,Integer> map = new HashMap<>();
		
		String s = "aaabbabc";
		
		for (int i = 0; i< s.length(); i++) {
			
			char ch = s.charAt(i);
			
			map.put(ch, map.getOrDefault(ch, 0)+1);
			
		}
		
		//Arrays.asList(ch).stream().flatMap(x->Stream.of(x)).mapToInt(x->Integer.parseInt(x)).forEach(System.out::println);
		
		
		Integer a = 5;
		
		Integer b =a;
		
		a=a+5;
		//System.out.println(b);
		
		stream4();
		//lis();
		//string();
		
		//stream();
		
		try {
			//finally2();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//sortMap();
		//stream2();
		//sorting();
		
		//optional();
		//System.out.println(map);
		
		ternary();
	}
	
	private static void ternary() {
		
		String brand = "rbs";
		
		String url = brand.equals("nwb")? "NWB Url" : brand.equals("rbs") ? "RBS" :"nwbi";
		
		System.out.println(url);
		
	}

	private static void charArray(){
char[] ch = {'1','3','5','2','4'};
		
		
		
		String aaa = new String(ch);
		aaa.chars().mapToObj(c -> (int)c - '0').forEach(System.out::println);;
		
	}
	
	
	private static void optional() {
		Optional<String> s1 = Optional.of(null); //will raise Null pointer exception 
		Optional<String> s2 = Optional.ofNullable(null);
		
		System.out.println(s1);
		System.out.println(s2.isPresent());
		
	}

	private static void sorting() {
		Student s1 = new Student("ABC", 20, 10, 30);
		Student s2 = new Student("PQR", 30, 50, 70);
		Student s3 = new Student("XYZ", 80, 90, 80);
		
		Student student = Arrays.asList(s1,s2,s3).stream().reduce((a,b) -> {
			int total1 = a.english+a.math+a.hindi;
			int total2 = b.english+b.math+b.hindi;
			
			if(total1 >total2) {
				return a;
			}
			return b;
			
		}).get();
		
		System.out.println(student);
		
	}
	private static void stream3() {
			
		List<Integer> list1 = Arrays.asList(0,1,2,3);
		List<Integer> list2 = Arrays.asList(1,2,3,4,5);
		
		//list1.stream().filter(i-> list2.contains(i)).forEach(System.out::println);
		//list1.stream().filter(list2::contains).forEach(System.out::println);		
		list2.stream().filter(i-> list1.stream().noneMatch(a-> a == i)).distinct().forEach(System.out::println);
		
	}
	
	private static void stream4() {
		
		  List<Person> persons = Arrays.asList(
		  new Person("John", 16),
		  new Person("Jane", 22),
		  new Person("Tom", 18),
		  new Person("Lucy", 15),
		  new Person("Anna", 18)
		  );


		  persons.stream().filter(p->p.getAge() <= 18).map(p->p.getName()).collect(Collectors.toList()).stream().forEach(System.out::println);
		   

		  HashMap<Integer, List<String>> collect = persons.stream().collect(Collectors.groupingBy(Person::getAge,HashMap::new, Collectors.mapping(Person::getName, Collectors.toList())));
		  collect.entrySet().stream().forEach(System.out::println);
		
			/*
			 * Map<City, Set<String>> namesByCity =
			 * people.stream().collect(groupingBy(Person::getCity, TreeMap::new,
			 * mapping(Person::getLastName, toSet())));
			 */
		  
	}
	
	
	private static void stream2() {
		String a[] = {"ganesh","ramesh","shubh","shubh","abc","red","aaaaa","zzzz"};
		
		Comparator<String> byLength = (s1,s2)-> Integer.compare(s1.length(), s2.length());
		Comparator<String> byString = (s1,s2)-> s1.compareTo(s2);
		
		
		
		List<String> list = Arrays.asList(a);
		
		Set<String> set = new TreeSet<String>(list);
		
		set.stream().forEach(System.out::println);
		
		System.out.println("==========================");
		Arrays.asList(a).stream().sorted(byLength.thenComparing(byString)).forEach(System.out::println);
		
		
	}

	private static void sortMap() {
		Map<String,Integer> map = new HashMap<String, Integer>();
		map.put("a", 6);
		map.put("z", 5);
		map.put("b", 2);
		map.put("d", 1);
		map.put("g", 8);
		map.put("k", 9);
		
		Set<Entry<String, Integer>> set = map.entrySet();
		
		Comparator<Entry<String, Integer>> byKey = (a,b)->a.getKey().compareTo(b.getKey());
		Comparator<Entry<String, Integer>> byVal = (a,b)->Integer.compare(a.getValue(), b.getValue());
		
		List<Entry<String, Integer>> byKeyList = set.stream().sorted(byKey).collect(Collectors.toList());
		List<Entry<String, Integer>> byValList = set.stream().sorted(byVal).collect(Collectors.toList());
		
		
		
		Map<String,Integer> byKeyMap = new LinkedHashMap<>();
		byKeyList.stream().forEach(x-> byKeyMap.put(x.getKey(), x.getValue()));
		
		System.out.println("Sorted By Key:");		
		byKeyMap.forEach((x,y)->System.out.println("key: "+x+" Value:"+y));
		
		
		Map<String,Integer> byValueMap = new LinkedHashMap<>();
		byValList.stream().forEach(x-> byValueMap.put(x.getKey(), x.getValue()));
		
		System.out.println("Sorted By Value:");
		byValueMap.forEach((x,y)->System.out.println("key: "+x+" Value:"+y));
		
	}

	private static void finally2() throws Exception {
		try {
			throw new Exception();
		}
		catch(Exception e) {
			throw new Exception();
			
		}
		finally {
			System.out.println("Hello from finally");
		}
		
	}

	private static void stream() {

        Map<String,Integer> map = new HashMap<>();
        map.put("a", 55);
        map.put("b", 55);
       

        int total = map.entrySet().stream().mapToInt(x-> x.getValue()).sum();
        System.out.println(total);
        
                
        String[] aa = {"a","b"};
        List<String> list = Arrays.asList(aa);
        System.out.println(list.stream().min(Comparator.reverseOrder()).get());		
	}

	private static void string() {
				
		String g1  = "Ganesh";
		String g2  = new String("Ganesh").intern();
		
		boolean equals = g1.equals(g2); //true
		boolean operator = (g1==g2); //true
		
		List<String> aa = new ArrayList<String>();
		aa.add(g2);
		aa.get(1);
		
		System.out.println("equals: "+equals);
		System.out.println("operator: "+operator);
				
		
		
	}

	private static void map() {
		Map<String, Integer> map = new ConcurrentHashMap<>();
		 
	        // Adding elements to the map
	        map.put("A", 1);
	        map.put("B", 2);
	        map.put("C", 3);
	        
	        for(Entry<String,Integer> element : map.entrySet()) {
	        	element.getValue();
	        	map.put("d", 5);
				
			}
	        
	        Iterator<String> iterator = map.keySet().iterator();
	        
	        while (iterator.hasNext()) {
	            String key = iterator.next();
	            map.put("Fifth", 50);
	        }
	        
	       
	        map.keySet().stream().forEach(System.out::println);
	        
		
	}

	public static void lis() {
		List<String> list = new ArrayList<>();
		

		list.add("element 1"); //0
		list.add("element 2"); 
		list.add("element 3");
		list.add("element 4");

		for(int i=0; i<list.size() ; i++) {
			list.add("ddd"); //works fine
          	list.remove("ddd"); //throw concurrent modification exception
		}
		
		 for(String element : list) {
	          	list.add("ddd"); //throw concurrent modification exception
	          	list.remove("ddd"); //throw concurrent modification exception
			}
		
		List<String> sublist = list.subList(1, 5);
		
		System.out.println(sublist);
	}
	
	public static int compute(Object s){
		return 1;
	}

}
class Person{
    private String name;
    private int age;
    
    
    Person(String s, int a){
        this.name = s;
        this.age=a;
    }
    
    public int getAge(){
        return age;
    }
    
    
    public String getName(){
        return name;
    }
    
    public static String myMethod(String par, int[] ar, int a){
    	
    	//Main method
//    	int[] ar = {1,2,3};
//  		int x =1;
//  		System.out.println(myMethod("abc",ar,ar[1]));
//  		System.out.println(Arrays.toString(ar));
//		
		try{
			System.out.println("try");
			
			ar[0] = ar[1]+ar[2];
			a = 6;
			if(par.equals(""))				
				return "hello";
				
			return par;	
		}
		catch (Exception ex){
		
			System.out.println("catch");
		}finally{
			System.out.println("finally");
			//return null;
		}
		
		return null;
	}

}
