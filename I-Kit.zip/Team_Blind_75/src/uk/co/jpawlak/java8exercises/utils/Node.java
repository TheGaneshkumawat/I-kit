package uk.co.jpawlak.java8exercises.utils;

@SuppressWarnings("unused")
public class Node {

    private final String name;

    public Node(String name) {
        this.name = name;
    }

    public String name() {
        return name;
    }

}
