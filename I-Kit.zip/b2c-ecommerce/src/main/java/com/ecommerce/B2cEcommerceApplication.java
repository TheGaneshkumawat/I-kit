package com.ecommerce;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.service.Formatter;
import com.google.common.base.Optional;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@SpringBootApplication
@EnableCircuitBreaker
public class B2cEcommerceApplication {

	public static void main(String[] args) {
		
		  ApplicationContext applicationContext = SpringApplication.run(B2cEcommerceApplication.class, args);
	        SomeService service = applicationContext.getBean(SomeService.class);
	        //service.doSth(args);
	        System.out.println("Greeting: "+service.getGreeting("Ganesh"));
	}
	
	
	@Service
	@PropertySource("classpath:ganesh.properties")
	class SomeService {
		
		@Value("${test.ganesh}")
		private String val;
		
		@Value("${test.ramesh}")
		private String val2;
	   
				
	    @Autowired
	    private Formatter formatter;
	    
	    public void doSth(String[] args){
	    	System.out.println(formatter.format()+" "+val+" "+val2);
	    }
	    
	    
	    @HystrixCommand(fallbackMethod = "defaultGreeting")
	    public String getGreeting(String username) {
	    	Optional.of(null);
	        return new RestTemplate().getForObject("http://localhost:9090/greeting/{username}", 
	          String.class, username);
	    }
	    
	    
	    private String defaultGreeting(String username) {
	        return "Hello User!";
	    }
	    
	}
	
}
