package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BeanB {

	private BeanA bean;
	
	@Autowired
	public BeanB(BeanA a) {
		this.bean = a;
	}
}
