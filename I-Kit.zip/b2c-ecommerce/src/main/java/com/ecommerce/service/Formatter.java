package com.ecommerce.service;

public interface Formatter {

	public String format();
}
