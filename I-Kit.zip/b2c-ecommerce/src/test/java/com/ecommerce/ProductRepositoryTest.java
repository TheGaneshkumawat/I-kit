package com.ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.ProductRepository;

@DataJpaTest
public class ProductRepositoryTest {

	@Autowired
	private ProductRepository productRepo;
	
	@Test
	public void findAll() {
		assertNotNull(productRepo);
		
		assertEquals(7, productRepo.findAll().size());	
		
	}
	
	@Test
	public void findByBrandId() {
		List<Product> list = productRepo.findByBrandId(4);
		
		assertEquals(5, list.size());	
	}
	
	@Test
	public void findByColorId() {
		List<Product> list = productRepo.findByColorId(1);
		
		assertEquals(2, list.size());	
	}
	
}
