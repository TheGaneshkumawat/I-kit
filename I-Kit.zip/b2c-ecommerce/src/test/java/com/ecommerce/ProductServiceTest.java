package com.ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.service.ProductServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

	@Mock
	ProductRepository productRepository;
	
	@InjectMocks
	ProductServiceImpl service;
	
	@Test
	public void findAll() {
		Product product = new Product();
        product.setSize("M");
        product.setId(1);
        product.setQuantity(1);
        product.setName("Stock 1");

        List<Product> products = Arrays.asList(product);
        
        Mockito.when(productRepository.findAll()).thenReturn(products);
        List<Product> all = service.findAll();
        
        assertNotNull(all);
        assertEquals(1,	all.size());
        
	}
	
	@Test
	public void getProducts() {
		Product product = new Product();
        product.setSize("M");
        product.setId(1);
        product.setQuantity(1);
        product.setName("Stock 1");

        List<Product> products = Arrays.asList(product);
        
        Mockito.when(productRepository.findAll()).thenReturn(products);
        List<Product> all = service.findAll();
        
        assertNotNull(all);
        assertEquals(1,	all.size());
        
	}
	
}
