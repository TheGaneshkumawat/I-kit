package com.ecommerce;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.ecommerce.controller.ProductController;
import com.ecommerce.entity.Product;
import com.ecommerce.service.ProductService;

/*
Controller
Service
Repository
Coverage
Swagger
Controller Advice
*/

@WebMvcTest(ProductController.class)
public class ProductAPITest {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService productService;
    
	/*
	 * @MockBean private BrandService brandService;
	 * 
	 * @MockBean private ColorService colorService;
	 * 
	 * @MockBean private ProductCategoryService categoryService;
	 */
    
    @Test
    public void findAll() throws Exception {
        Product product = new Product();
        product.setSize("M");
        product.setId(1);
        product.setQuantity(1);
        product.setName("Stock 1");

        List<Product> products = Arrays.asList(product);
        given(productService.findAll()).willReturn(products);

        //this.mockMvc.perform(get("/api/products/filter/size/M"))
        this.mockMvc.perform(get("/api/products"))
                .andExpect(status().isOk())
                .andExpect(content().json("[{'id': 1,'name': 'Stock 1','quantity': 1}]"));
    }
    
    @Test
    public void findByFilter() throws Exception {
        Product product = new Product();
        product.setSize("M");
        product.setId(1);
        product.setQuantity(1);
        product.setName("Stock 1");

        List<Product> products = Arrays.asList(product);
        given(productService.getProducts("size", "M")).willReturn(products);

        this.mockMvc.perform(get("/api/products/filter/size/M"))        
                .andExpect(status().isOk())
                .andExpect(content().json("[{'id': 1,'name': 'Stock 1','quantity': 1}]"));
    }
}