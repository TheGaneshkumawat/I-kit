insert into product values(1,'levis','white',1200,'shirt',38,'sku1');
insert into product values(2,'levis','black',1500,'jeans',32,'sku2');
insert into product values(3,'lp','red',1200,'t-shirt',38,'sku3');
insert into product values(4,'lp','black',1200,'belt',32,'sku4');
insert into product values (5,'john players','blue',2500,'jeans',38,'sku5');
insert into product values(6,'vans','grey',2500,'shoes',8,'sku6');
insert into product values(7,'vans','black',3000,'slip-ons',38,'sku7');
insert into product values(8,'levis','red',2200,'polo-shirt',38,'sku8');
insert into product values(9,'arrow','black',3500,'blazer',38,'sku7');
insert into product values(10,'blackberry','white',4000,'shirt',38,'sku10');


insert into seller values(20,1,30,'abc');
insert into seller values(21,2,50,'abc');
insert into seller values(22,5,10,'abc');
insert into seller values(23,3,30,'abc');
insert into seller values(24,3,30,'xyz');
insert into seller values(25,4,30,'abc');
insert into seller values(26,6,30,'abc');
insert into seller values(27,7,30,'abc');
insert into seller values(28,8,50,'abc');
insert into seller values(29,9,10,'abc');
insert into seller values(30,10,25,'abc');
insert into seller values(31,5,30,'xyz');
insert into seller values(32,4,30,'xyz');
insert into seller values(33,10,30,'xyz');
