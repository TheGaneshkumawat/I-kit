package com.demo.processor;

import com.demo.comparators.CSVFileComparator;
import com.demo.comparators.FileComparator;

public class JSONFileProcessor extends FileProcessor {

	@Override
	public FileComparator getComparator() {
		
		return new CSVFileComparator();
	}

}
