package com.demo.processor;

import java.io.File;

import com.demo.comparators.FileComparator;

public abstract class FileProcessor {
	
	
	
	public abstract FileComparator getComparator();
	
	public String processFile(File source, File target) {
		
		//Common steps 
		FileComparator comparator = getComparator();		
		String comparisonResult = comparator.compare(source,target);
		
		//POST comparison common steps
		
		
		return comparisonResult;
	}

}
