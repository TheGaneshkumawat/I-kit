package com.demo.processor;

import com.demo.comparators.FileComparator;
import com.demo.comparators.JSONFileComparator;

public class CSVFileProcessor extends FileProcessor {

	@Override
	public FileComparator getComparator() {
		
		return new JSONFileComparator();
	}

}
