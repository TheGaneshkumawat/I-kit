package com.demo;

import java.io.File;

import com.demo.processor.CSVFileProcessor;
import com.demo.processor.FileProcessor;
import com.demo.processor.JSONFileProcessor;

public class Client {
	
	public static void main(String[] arg) {		
				
		//read config
		//Connection open
		//ls files
		//check if required files present
		
		//initiate Parser based on some condition
		
		String input = arg[0];
		
		FileProcessor processor = null;
		
		if(input.equals("CSV")){
			processor = new CSVFileProcessor();
		}
		else {
			processor = new JSONFileProcessor();
		}
		
		//file processing
		String result = processor.processFile(new File("file1"), new File("file1"));
		
		
	}


}
