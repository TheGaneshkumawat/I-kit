package com.demo.comparators;

import java.io.File;

public class CSVFileComparator implements FileComparator {

	@Override
	public String compare(File source, File target) {
		// TODO Auto-generated method stub
		return null;
	}

}
