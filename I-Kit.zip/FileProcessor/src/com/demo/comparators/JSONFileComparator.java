package com.demo.comparators;

import java.io.File;

public class JSONFileComparator implements FileComparator {

	@Override
	public String compare(File source, File target) {
		// TODO Auto-generated method stub
		return null;
	}

}
