package com.demo.comparators;

import java.io.File;

public interface FileComparator {
	
	public String compare(File source, File target);
	
	  default void show() 
	    { 
	        System.out.println("Default TestInterface1"); 
	    } 
	  default void show2() 
	    { 
	        System.out.println("Default TestInterface1"); 
	    } 

}
